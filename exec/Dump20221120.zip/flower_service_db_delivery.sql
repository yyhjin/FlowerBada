-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: k7a405.p.ssafy.io    Database: flower_service_db
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `delivery`
--

DROP TABLE IF EXISTS `delivery`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `delivery` (
  `id` int NOT NULL AUTO_INCREMENT,
  `created_date` datetime DEFAULT CURRENT_TIMESTAMP,
  `is_deleted` bit(1) DEFAULT b'0',
  `updated_date` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `flowers_count` int DEFAULT '0',
  `img_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `order_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` int NOT NULL,
  `receiver_address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `receiver_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `receiver_phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sender_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sender_phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `state_id` int DEFAULT NULL,
  `rolling_id` int DEFAULT NULL,
  `user_id` int DEFAULT NULL,
  `sender_msg` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKepsvuv7n8ns5u11b6tvhv4u79` (`state_id`),
  KEY `FKstjyolew6vbybc48d4ygs7dua` (`rolling_id`),
  KEY `FK5ew3qef4wkv137uiky3nd663e` (`user_id`),
  CONSTRAINT `FK5ew3qef4wkv137uiky3nd663e` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`),
  CONSTRAINT `FKepsvuv7n8ns5u11b6tvhv4u79` FOREIGN KEY (`state_id`) REFERENCES `delivery_state` (`id`),
  CONSTRAINT `FKstjyolew6vbybc48d4ygs7dua` FOREIGN KEY (`rolling_id`) REFERENCES `rolling_paper` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `delivery`
--

LOCK TABLES `delivery` WRITE;
/*!40000 ALTER TABLE `delivery` DISABLE KEYS */;
INSERT INTO `delivery` VALUES (1,'2022-11-15 17:03:38',_binary '\0','2022-11-15 22:09:37',10,'paymentitem/y6gV20UJ4-20221115173649.png','1',39400,'군포시어쩌구','이홍주','01065221412','','',1,6,3,''),(2,'2022-11-15 17:06:27',_binary '\0','2022-11-15 22:09:37',10,'paymentitem/y6gV20UJ4-20221115173649.png','2',39400,'역삼역 1번출구','gd','11414','','',1,6,4,''),(3,'2022-11-15 17:36:59',_binary '\0','2022-11-15 17:36:59',10,'paymentitem/y6gV20UJ4-20221115173649.png','3',39400,'34123412341234','1234','123412','1312','3123123123123',1,6,4,''),(4,'2022-11-15 18:09:11',_binary '\0','2022-11-15 22:09:37',2,'paymentitem/y6gV20UJ4-20221115173649.png','4',4100,'wtwrt','wr','twrtrt','','',1,9,4,''),(5,'2022-11-15 22:21:09',_binary '\0','2022-11-15 22:21:09',3,'paymentitem/iQxmYojc9-20221115222017.png','5',10300,'서울특별시','김수만','01012345678','','',1,3,2,''),(6,'2022-11-15 13:50:51',_binary '\0','2022-11-15 13:50:51',4,'paymentitem/y6gV20UJ4-20221115225042.png','6',19600,'fsf','sf','asfa','','',1,6,4,''),(7,'2022-11-15 13:52:55',_binary '\0','2022-11-15 13:52:55',4,'paymentitem/y6gV20UJ4-20221115225239.png','7',19600,'sdsd','sd','sdsd','','',1,6,4,''),(8,'2022-11-15 13:57:14',_binary '\0','2022-11-15 13:57:14',2,'paymentitem/rGF8K429Y-20221115225701.png','8',4100,'우리집','하이','01010101010','','',1,9,4,''),(9,'2022-11-15 23:42:55',_binary '\0','2022-11-15 23:42:55',2,'paymentitem/VnRP1gfPt-20221115144243.png','9',5300,'asdfsadf','asdf','123123','','',1,16,2,''),(10,'2022-11-16 07:54:30',_binary '\0','2022-11-16 07:54:30',0,'paymentitem/umrg0h-20221115225410.png','10',500,'hj','hh','hj','gg','jj',1,18,3,''),(11,'2022-11-16 12:59:55',_binary '\0','2022-11-16 12:59:55',2,'paymentitem/7bS3uwB6S-20221116125857.png','13',8300,'역삼역 1번출구','배윤호','01012345678','오석호','010-9013-8646',1,34,4,'맛있게 포장해주시고 좋은거 많이 선물해주시고 이것저것 다 많이 적어주시면 감사드릴 것 같습니다!'),(12,'2022-11-16 14:25:38',_binary '\0','2022-11-16 14:25:38',0,'paymentitem/umrg0h-20221116052522.png','14',5500,'ㅋㅋ','ㅋㅋ','ㅋㅋ','','',1,18,3,'ㅎㅎ'),(13,'2022-11-16 14:27:05',_binary '\0','2022-11-16 14:27:05',0,'paymentitem/y6gV20UJ4-20221116052635.png','15',1000,'??','ㅜㅜ','ㅜㅜ','ㅋㅋ','ㅋㅋ',1,6,3,'ㅋㅋ'),(15,'2022-11-16 16:08:00',_binary '\0','2022-11-16 16:08:00',0,'paymentitem/7TdfwO-20221116070751.png','17',500,'ㅎ','ㅎ','ㅎ','','',1,39,3,'ㅋ'),(16,'2022-11-17 07:33:44',_binary '\0','2022-11-17 07:33:44',4,'paymentitem/tuE9sW495-20221116223252.png','18',13300,'대전','홍길동','010775474767','','',1,53,24,''),(17,'2022-11-17 07:34:30',_binary '\0','2022-11-17 07:34:30',4,'paymentitem/tuE9sW495-20221116223402.png','19',13300,'대전','홍길동','01075289526','','',1,53,24,''),(18,'2022-11-17 10:47:48',_binary '\0','2022-11-17 10:47:48',2,'paymentitem/0NSvUhj-20221117014731.png','20',5300,'1234','홍주','홍주','','',1,2,3,'음..'),(19,'2022-11-17 11:25:44',_binary '\0','2022-11-17 11:25:44',7,'paymentitem/40T21-20221117022511.png','21',22000,'멀티캠퍼스','리홍주','0101435456','','',1,13,2,'테스트용입니다.'),(20,'2022-11-18 03:37:18',_binary '\0','2022-11-18 03:37:18',3,'paymentitem/94rp53h-20221118123701.png','22',9100,'ㅇ','ㅇ','ㅇ','','',1,107,4,'ㅇㄹㅇㄹ'),(21,'2022-11-19 10:43:29',_binary '\0','2022-11-19 10:43:29',8,'paymentitem/y6gV20UJ4-20221119014209.png','23',28900,'역삼캠퍼스 12층 1201호','서울_A405_이홍주','01012345678','','',1,6,3,''),(22,'2022-11-19 14:37:30',_binary '\0','2022-11-19 14:37:30',5,'paymentitem/834TBgs-20221119053555.png','24',13900,'역삼캠퍼스 12층 1201호','이현우','우리반','이현우','',1,55,21,'꽃은 많이 필요는 없고.. 롤링페이퍼 적은 것들 보내주시면 감사합니다'),(23,'2022-11-19 17:53:53',_binary '\0','2022-11-19 17:53:53',6,'paymentitem/cdyu9n-20221119085231.png','25',23600,'역삼캠퍼스 11층 1101호','서울_A307_박지원','01051265464','','',1,63,31,''),(25,'2022-11-19 17:55:47',_binary '\0','2022-11-19 17:55:47',6,'paymentitem/cdyu9n-20221119085510.png','27',23600,'역삼캠퍼스 11층 1101호','서울_A307_박지원','01051265464','','',1,63,31,''),(27,'2022-11-19 18:02:10',_binary '\0','2022-11-19 18:02:10',6,'paymentitem/cdyu9n-20221119085846.png','29',23600,'여의도 한강공원','금잔디','010-1234-5678','구준표','010-9876-5432',1,63,2,'최대한 빨리 배송오도록.'),(28,'2022-11-19 19:22:59',_binary '\0','2022-11-19 19:22:59',5,'paymentitem/B4NEf-20221119102224.png','30',17100,'서울 역삼 캠퍼스 11층 1102호','서울_A307_허설','01076436603','','',1,59,30,''),(29,'2022-11-19 23:59:52',_binary '\0','2022-11-19 23:59:52',6,'paymentitem/y6gV20UJ4-20221119145858.png','31',24100,'역삼캠퍼스 12층 1201호','혼주','01011111111','','',1,6,3,''),(30,'2022-11-20 00:02:00',_binary '\0','2022-11-20 00:02:00',6,'paymentitem/y6gV20UJ4-20221119150117.png','32',24100,'서울테스트','테스트','01065221412','','',1,6,3,''),(31,'2022-11-20 00:04:08',_binary '\0','2022-11-20 00:04:08',8,'paymentitem/y6gV20UJ4-20221119150352.png','33',28900,'12341234','다시테스트','1231234','','',1,6,3,''),(32,'2022-11-20 00:27:59',_binary '\0','2022-11-20 00:27:59',6,'paymentitem/y6gV20UJ4-20221119152742.png','34',24100,'배송주소','홍주','01012345678','','',1,6,3,''),(33,'2022-11-20 11:19:49',_binary '\0','2022-11-20 11:19:49',8,'paymentitem/WJ3JoQUp-20221120021924.png','35',27800,'역삼 캠퍼스','배윤호','01011111111','','',1,98,5,'');
/*!40000 ALTER TABLE `delivery` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-11-20 17:23:29
