-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: k7a405.p.ssafy.io    Database: flower_service_db
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `flower_item`
--

DROP TABLE IF EXISTS `flower_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `flower_item` (
  `id` int NOT NULL AUTO_INCREMENT,
  `created_date` datetime DEFAULT CURRENT_TIMESTAMP,
  `is_deleted` bit(1) DEFAULT b'0',
  `updated_date` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `flower_language` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `img_bud` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `img_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `point` int NOT NULL,
  `price` int NOT NULL,
  `season` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flower_item`
--

LOCK TABLES `flower_item` WRITE;
/*!40000 ALTER TABLE `flower_item` DISABLE KEYS */;
INSERT INTO `flower_item` VALUES (1,'2022-11-15 07:25:37',_binary '\0','2022-11-15 07:56:44','정열적인 사랑, 열정, 아름다움','fixed-size/flowerbud/flowerbud_2_fixed.png','fixed-size/flower/flower_2_fixed.png','빨강 장미',0,3000,NULL),(2,'2022-11-15 07:25:39',_binary '\0','2022-11-15 07:56:44','내 모든 것을 그대에게','fixed-size/flowerbud/flowerbud_9_fixed.png','fixed-size/flower/flower_9_fixed.png','국화',0,1800,'여름,가을'),(3,'2022-11-15 07:25:40',_binary '\0','2022-11-15 07:56:44','희망, 이루어질 수 없는 사랑','fixed-size/flowerbud/flowerbud_7_fixed.png','fixed-size/flower/flower_7_fixed.png','노랑 튤립',0,4000,'봄,여름'),(4,'2022-11-15 07:25:43',_binary '\0','2022-11-15 07:56:44','사랑의 맹세','fixed-size/flowerbud/flowerbud_1_fixed.png','fixed-size/flower/flower_1_fixed.png','분홍 장미',5,3500,NULL),(5,'2022-11-15 07:25:45',_binary '\0','2022-11-15 07:56:44','질투와 시기, 완벽한 성취','fixed-size/flowerbud/flowerbud_4_fixed.png','fixed-size/flower/flower_4_fixed.png','노랑 장미',5,3800,NULL),(6,'2022-11-15 07:25:47',_binary '\0','2022-11-15 07:56:44','존경, 순결, 새로운 시작','fixed-size/flowerbud/flowerbud_3_fixed.png','fixed-size/flower/flower_3_fixed.png','흰 장미',5,2800,NULL),(7,'2022-11-15 07:25:49',_binary '\0','2022-11-15 07:56:44','사랑의 고백','fixed-size/flowerbud/flowerbud_5_fixed.png','fixed-size/flower/flower_5_fixed.png','빨강 튤립',20,3000,'봄,여름'),(8,'2022-11-15 07:25:50',_binary '\0','2022-11-15 07:56:44','수줍음, 부끄러움','fixed-size/flowerbud/flowerbud_6_fixed.png','fixed-size/flower/flower_6_fixed.png','주황 튤립',20,4000,'봄,여름'),(9,'2022-11-15 07:25:51',_binary '\0','2022-11-16 09:57:57','순수한 사랑, 변함없는 사랑','fixed-size/flowerbud/flowerbud_10_fixed.png','fixed-size/flower/flower_10_fixed.png','백합',10,3000,'봄,여름'),(10,'2022-11-15 07:25:53',_binary '\0','2022-11-15 07:56:44','냉정, 거만, 무정','fixed-size/flowerbud/flowerbud_8_fixed.png','fixed-size/flower/flower_8_fixed.png','수국',25,5000,'봄,여름'),(11,'2022-11-15 07:25:54',_binary '\0','2022-11-15 07:56:44','건강을 비는 사랑, 존경','fixed-size/flowerbud/flowerbud_11_fixed.png','fixed-size/flower/flower_11_fixed.png','카네이션',15,1900,'여름,가을');
/*!40000 ALTER TABLE `flower_item` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-11-20 17:23:29
