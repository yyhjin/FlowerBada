-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: k7a405.p.ssafy.io    Database: flower_service_db
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `rolling_user`
--

DROP TABLE IF EXISTS `rolling_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rolling_user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `created_date` datetime DEFAULT CURRENT_TIMESTAMP,
  `is_deleted` bit(1) DEFAULT b'0',
  `updated_date` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `item_id` int DEFAULT NULL,
  `user_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKthoscijiv6xukexwftis0vjs1` (`item_id`),
  KEY `FK8n397svbq8ofcn9k22r3t7n6t` (`user_id`),
  CONSTRAINT `FK8n397svbq8ofcn9k22r3t7n6t` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`),
  CONSTRAINT `FKthoscijiv6xukexwftis0vjs1` FOREIGN KEY (`item_id`) REFERENCES `rolling_item` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=72 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rolling_user`
--

LOCK TABLES `rolling_user` WRITE;
/*!40000 ALTER TABLE `rolling_user` DISABLE KEYS */;
INSERT INTO `rolling_user` VALUES (1,'2022-11-15 16:59:15',_binary '\0','2022-11-15 16:59:15',9,3),(4,'2022-11-15 17:21:03',_binary '\0','2022-11-15 17:21:03',7,6),(14,'2022-11-15 14:01:51',_binary '\0','2022-11-15 14:01:51',4,4),(26,'2022-11-16 16:17:39',_binary '\0','2022-11-16 16:17:39',5,4),(27,'2022-11-16 16:18:07',_binary '\0','2022-11-16 16:18:07',6,4),(28,'2022-11-16 16:20:29',_binary '\0','2022-11-16 16:20:29',9,4),(29,'2022-11-16 16:23:54',_binary '\0','2022-11-16 16:23:54',8,4),(30,'2022-11-16 16:42:06',_binary '\0','2022-11-16 16:42:06',5,3),(31,'2022-11-16 16:45:59',_binary '\0','2022-11-16 16:45:59',7,4),(32,'2022-11-16 17:01:00',_binary '\0','2022-11-16 17:01:00',9,22),(33,'2022-11-16 17:02:19',_binary '\0','2022-11-16 17:02:19',8,24),(34,'2022-11-16 17:02:24',_binary '\0','2022-11-16 17:02:24',9,24),(35,'2022-11-16 17:17:47',_binary '\0','2022-11-16 17:17:47',4,31),(36,'2022-11-16 17:17:53',_binary '\0','2022-11-16 17:17:53',8,31),(37,'2022-11-16 17:53:45',_binary '\0','2022-11-16 17:53:45',4,5),(38,'2022-11-16 17:53:53',_binary '\0','2022-11-16 17:53:53',5,5),(39,'2022-11-16 18:47:50',_binary '\0','2022-11-16 18:47:50',6,30),(40,'2022-11-16 19:53:50',_binary '\0','2022-11-16 19:53:50',7,3),(41,'2022-11-16 19:54:27',_binary '\0','2022-11-16 19:54:27',6,3),(42,'2022-11-16 21:34:54',_binary '\0','2022-11-16 21:34:54',6,5),(43,'2022-11-16 21:35:03',_binary '\0','2022-11-16 21:35:03',7,5),(44,'2022-11-16 23:16:08',_binary '\0','2022-11-16 23:16:08',4,3),(45,'2022-11-16 23:16:27',_binary '\0','2022-11-16 23:16:27',6,36),(46,'2022-11-16 23:31:40',_binary '\0','2022-11-16 23:31:40',8,5),(47,'2022-11-17 02:39:54',_binary '\0','2022-11-17 02:39:54',7,36),(48,'2022-11-17 08:45:50',_binary '\0','2022-11-17 08:45:50',8,3),(49,'2022-11-17 09:08:46',_binary '\0','2022-11-17 09:08:46',5,43),(50,'2022-11-17 09:17:42',_binary '\0','2022-11-17 09:17:42',8,44),(51,'2022-11-17 09:19:05',_binary '\0','2022-11-17 09:19:05',4,42),(52,'2022-11-17 10:45:36',_binary '\0','2022-11-17 10:45:36',9,5),(53,'2022-11-17 10:58:09',_binary '\0','2022-11-17 10:58:09',9,36),(54,'2022-11-17 11:06:23',_binary '\0','2022-11-17 11:06:23',4,1),(55,'2022-11-17 11:06:37',_binary '\0','2022-11-17 11:06:37',9,1),(56,'2022-11-17 11:08:51',_binary '\0','2022-11-17 11:08:51',5,1),(57,'2022-11-17 14:49:23',_binary '\0','2022-11-17 14:49:23',7,31),(58,'2022-11-17 14:49:27',_binary '\0','2022-11-17 14:49:27',5,31),(59,'2022-11-17 14:49:35',_binary '\0','2022-11-17 14:49:35',6,31),(60,'2022-11-17 14:55:36',_binary '\0','2022-11-17 14:55:36',8,54),(61,'2022-11-17 15:03:29',_binary '\0','2022-11-17 15:03:29',9,56),(62,'2022-11-18 22:21:54',_binary '\0','2022-11-18 22:21:54',9,31),(63,'2022-11-19 13:21:41',_binary '\0','2022-11-19 13:21:41',5,81),(64,'2022-11-19 16:07:01',_binary '\0','2022-11-19 16:07:01',9,82),(65,'2022-11-19 16:19:27',_binary '\0','2022-11-19 16:19:27',5,2),(67,'2022-11-19 19:55:50',_binary '\0','2022-11-19 19:55:50',4,38),(68,'2022-11-19 19:58:35',_binary '\0','2022-11-19 19:58:35',8,23),(69,'2022-11-19 20:22:08',_binary '\0','2022-11-19 20:22:08',9,85),(70,'2022-11-19 22:18:59',_binary '\0','2022-11-19 22:18:59',7,90),(71,'2022-11-19 22:42:40',_binary '\0','2022-11-19 22:42:40',5,86);
/*!40000 ALTER TABLE `rolling_user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-11-20 17:23:27
