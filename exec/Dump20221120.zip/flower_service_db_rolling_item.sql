-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: k7a405.p.ssafy.io    Database: flower_service_db
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `rolling_item`
--

DROP TABLE IF EXISTS `rolling_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rolling_item` (
  `id` int NOT NULL AUTO_INCREMENT,
  `created_date` datetime DEFAULT CURRENT_TIMESTAMP,
  `is_deleted` bit(1) DEFAULT b'0',
  `updated_date` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `capacity` int DEFAULT NULL,
  `img_back` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `img_front` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `img_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `point` int DEFAULT NULL,
  `price` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rolling_item`
--

LOCK TABLES `rolling_item` WRITE;
/*!40000 ALTER TABLE `rolling_item` DISABLE KEYS */;
INSERT INTO `rolling_item` VALUES (1,'2022-11-15 07:29:35',_binary '\0','2022-11-15 07:52:44',7,'rolling_item/rolling_1_back.png','rolling_item/rolling_1_front.png','fixed-size/rolling/rolling_1_fixed.png','분홍색 기본 꽃다발',0,0),(2,'2022-11-15 07:29:35',_binary '\0','2022-11-15 07:52:44',7,'rolling_item/rolling_2_back.png','rolling_item/rolling_2_front.png','fixed-size/rolling/rolling_2_fixed.png','보라색 기본 꽃다발',0,0),(3,'2022-11-15 07:29:35',_binary '\0','2022-11-15 07:52:44',7,'rolling_item/rolling_3_back.png','rolling_item/rolling_3_front.png','fixed-size/rolling/rolling_3_fixed.png','흰색 기본 꽃다발',0,0),(4,'2022-11-15 07:29:35',_binary '\0','2022-11-16 13:09:55',7,'rolling_item/rolling_4_back.png','rolling_item/rolling_4_front.png','fixed-size/rolling/rolling_4_fixed.png','신문지 기본 꽃다발',50,1000),(5,'2022-11-15 07:29:35',_binary '\0','2022-11-15 07:53:54',8,'rolling_item/rolling_5_back.png','rolling_item/rolling_5_front.png','fixed-size/rolling/rolling_5_fixed.png','하늘색 고급 꽃다발',10,2000),(6,'2022-11-15 07:29:35',_binary '\0','2022-11-16 13:10:17',8,'rolling_item/rolling_6_back.png','rolling_item/rolling_6_front.png','fixed-size/rolling/rolling_6_fixed.png','노란색 고급 꽃다발',10,2000),(7,'2022-11-15 07:29:35',_binary '\0','2022-11-16 13:10:17',8,'rolling_item/rolling_7_back.png','rolling_item/rolling_7_front.png','fixed-size/rolling/rolling_7_fixed.png','연두색 고급 꽃다발',10,2000),(8,'2022-11-15 07:29:35',_binary '\0','2022-11-15 07:53:54',10,'rolling_item/rolling_8_back.png','rolling_item/rolling_8_front.png','fixed-size/rolling/rolling_8_fixed.png','갈색 라탄 꽃바구니',20,5000),(9,'2022-11-15 07:29:35',_binary '\0','2022-11-15 07:53:54',10,'rolling_item/rolling_9_back.png','rolling_item/rolling_9_front.png','fixed-size/rolling/rolling_9_fixed.png','베이지색 라탄 꽃바구니',20,5000);
/*!40000 ALTER TABLE `rolling_item` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-11-20 17:23:28
